# Test Automation of Wire Insights

##  Project Overview
`WIRE_INSIGHTS` is an end-to-end test automation project for a web application, built using [Playwright](https://playwright.dev/). It provides automated UI tests for various modules and features, supporting multiple environments (QA, Dev, Staging, Prod) with environment-specific configuration.
This project is a **Playwright-based end-to-end test automation framework** designed for web applications.  
### It supports:
- **Cross-browser testing** (Chromium, Firefox, WebKit)
- **Headless and headed execution modes**
- **Tag-based test filtering** for flexible runs
- **Screenshots, videos, and traces** for debugging
- **CI/CD integration** for automated pipelines

##  Features
- Run tests in **headless** or **headed** mode
- Execute **single test suites** or **specific tests by title**
- Capture **screenshots or videos** on failure
- Generate **Custom HTML reports** and **trace files**
- Supports **environment-specific configs** using `cross-env`

##  Setup Instructions
### 1. Install Dependencies
```bash
npm install
```

### 2. Install Playwright Browsers
```bash
npx playwright install
```

### 3. Project Structure
```
project-root/
├── src/                  # Resources like, env, fixtures, pages, logger, utils
├── tests/                # Test specs (.spec.ts)
├── config/
│   └── playwright.config.ts  # Playwright configuration
├── test-report/          # Dashboard HTML execution report
├── package.json          # NPM scripts
└── README.md             # Project documentation
```
## Running Tests on different Environment

Use the following npm scripts to run tests for different environments:

- **QA:**
  ```sh
  npm run test:qa
  ```
- **Dev:**
  ```sh
  npm run test:dev
  ```
- **Staging:**
  ```sh
  npm run test:staging
  ```
- **Prod:**
  ```sh
  npm run test:prod
  ```

##  Execution Strategies
### Run All Tests
```bash
npm run test:test     # Specific for the test environment.
```

### Run a Single Test Suite
```bash
npm run test:test -- tests/Planning.spec.ts     # Execute single suite.
```

### Run Tests by Title (Grep)
```bash
npm run test:test -- -g "Planning"       # Execute test with keywords
```

### Run Tests by Tag
Add tags in your test:
```ts
test('Planning feature @planning', async ({ page }) => {
  // test code
});
```
Run tagged tests:
```bash
npm run test:test -- --grep "@planning"
```

### Run in Headless or Headed Mode
- **Headless (default in CI):**
```bash
npm run test:test
```
- **Headed:**
```bash
npm run test:test -- --headed
```

### Run in Specific Browser
```bash
npm run test:test -- --project=chromium
npm run test:test -- --project=firefox
npm run test:test -- --project=webkit
```

##  Screenshots & Debugging
### Capture Screenshot in Test
```ts
await page.screenshot({ path: 'screenshots/state.png', fullPage: false });
```

### Auto Screenshot on Failure
In `playwright.config.ts`:
```ts
use: {
  screenshot: 'only-on-failure',
  video: 'retain-on-failure',
  trace: 'retain-on-failure'
}
```

### Enable Trace for Debugging
```bash
npm run test:test -- --trace on
```
Open trace:
```bash
npx playwright show-trace trace.zip
```

##  Viewport & Zoom Settings
- Set viewport for consistent layout:
```ts
use: {
  viewport: { width: 1920, height: 1080 },
  deviceScaleFactor: 1,
  isMobile: false
}
```

##  Troubleshooting
- **Headless vs Headed differences:**
  - Use fixed viewport `{ width: 1920, height: 1080 }`
  - Disable animations: `reducedMotion: 'reduce'`
- **Element not clickable in headless:**
  - Ensure visibility: `await expect(locator).toBeVisible()`
  - Scroll into view: `await locator.scrollIntoViewIfNeeded()`

##  Best Practices
- Use **accessible locators** (`getByRole`, `getByLabel`) for stability
- Avoid `.first()` unless scoped to a unique container
- Tag tests for flexible execution (`@smoke`, `@regression`)           **#If required.**
- Enable **trace + screenshot on failure** for CI runs
- Keep **viewport consistent** across environments

##  Reports
Generate HTML report:
```bash
npx playwright show-report
```
   **You can see the custom reports at: .\test-report\WireInsight_Automation_Exe_Report.html**