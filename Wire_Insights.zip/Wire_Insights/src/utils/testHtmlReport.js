const fs = require('fs');
const path = require('path');

/**
 * This custom reporter will give us very detail info about latest execution in dashboard.
 * @author Suhas Ghodake
 * Playwright custom HTML reporter that generates:
 * - test-report/index.html
 * - test-report/results.json
 * - test-report/screenshots/
 * - test-report/traces/
 *
 */

class CustomHtmlReporter {
  constructor(options) {
    this.results = [];
    this.suites = new Map();
    this.startTime = new Date();
    this.outputDir = (options && options.outputDir) || path.join(process.cwd(), 'test-report');
    this.screenshotsDir = path.join(this.outputDir, 'screenshots');
    this.tracesDir = path.join(this.outputDir, 'traces');
  }

  onBegin(config, suite) {
    try {
      if (fs.existsSync(this.outputDir)) fs.rmSync(this.outputDir, { recursive: true, force: true });
    } catch (e) {
      // ignore cleanup errors
    }
    fs.mkdirSync(this.outputDir, { recursive: true });
    fs.mkdirSync(this.screenshotsDir, { recursive: true });
    fs.mkdirSync(this.tracesDir, { recursive: true });
    console.log(`CustomHtmlReporter: output -> ${this.outputDir}`);
  }

  onTestEnd(test, result) {
    try {
      // titlePath may be function or array depending on Playwright version
      const titlePath = Array.isArray(test.titlePath) ? test.titlePath : (typeof test.titlePath === 'function' ? test.titlePath() : [test.title]);
      const project = 'Wire Insight'; //Giving hardcoded name of the project.
      const file = (test.location && test.location.file) ? path.basename(test.location.file) : (test.file ? path.basename(test.file) : 'unknown');
      const suiteName = path.basename(file);
      const testCase = titlePath && titlePath.length ? titlePath[titlePath.length - 1] : (test.title || 'Unnamed Test');

      const status = result.status; // 'passed'|'failed'|'skipped'|'timedOut'|'interrupted'
      const duration = result.duration || 0;

      let screenshotRel = '';
      let screenshotDataUrl = '';
      let traceRel = '';

      if (Array.isArray(result.attachments) && result.attachments.length) {
        // Prefer an attachment that looks like a screenshot
        const shot = result.attachments.find(a => ((a.name || '').toLowerCase().includes('screenshot')) || ((a.contentType || '').startsWith('image/')));
        if (shot) {
          if (shot.path && fs.existsSync(shot.path)) {
            const destName = `${Date.now()}-${Math.random().toString(36).slice(2,6)}-${path.basename(shot.path)}`;
            const dest = path.join(this.screenshotsDir, destName);
            try { fs.copyFileSync(shot.path, dest); screenshotRel = path.join('screenshots', destName); } catch(e){ screenshotRel = ''; }
            try {
              const buf = fs.readFileSync(dest);
              const b64 = buf.toString('base64');
              const mime = guessImageMime(shot.contentType, dest);
              screenshotDataUrl = `data:${mime};base64,${b64}`;
            } catch(e) {}
          } else if (shot.body) {
            const ext = (shot.contentType && shot.contentType.includes('png')) ? '.png' : '.png';
            const destName = `${Date.now()}-${Math.random().toString(36).slice(2,6)}-screenshot${ext}`;
            const dest = path.join(this.screenshotsDir, destName);
            fs.writeFileSync(dest, shot.body);
            screenshotRel = path.join('screenshots', destName);
            try {
              const b64 = Buffer.from(shot.body).toString('base64');
              const mime = guessImageMime(shot.contentType, dest);
              screenshotDataUrl = `data:${mime};base64,${b64}`;
            } catch(e) {}
          }
        }

        // Trace attachment (zip)
        const trace = result.attachments.find(a => ((a.name || '').toLowerCase() === 'trace') || ((a.name || '').toLowerCase().includes('trace')));
        if (trace) {
          if (trace.path && fs.existsSync(trace.path)) {
            const destName = `${Date.now()}-${Math.random().toString(36).slice(2,6)}-${path.basename(trace.path)}`;
            const dest = path.join(this.tracesDir, destName);
            try { fs.copyFileSync(trace.path, dest); traceRel = path.join('traces', destName); } catch(e){ traceRel = ''; }
          } else if (trace.body) {
            const destName = `${Date.now()}-${Math.random().toString(36).slice(2,6)}-trace.zip`;
            const dest = path.join(this.tracesDir, destName);
            fs.writeFileSync(dest, trace.body);
            traceRel = path.join('traces', destName);
          }
        }
      }

      const err = result.error || null;
      const error_message = err ? (err.message || '') : '';
      const error_stack = err ? (err.stack || '') : '';
      const error_snippet = (err && err.snippet) ? err.snippet : '';

      const failure_bucket = (status === 'failed' || status === 'timedOut') ? bucketFailure(error_message, status) : '';

      const row = {
        project,
        suite: suiteName,
        test_case: testCase,
        status,
        duration,
        file,
        failure_bucket,
        error_message,
        error_stack,
        error_snippet,
        screenshot: screenshotRel,
        screenshotDataUrl,
        trace: traceRel
      };

      this.results.push(row);

      // update aggregates
      const agg = this.suites.get(suiteName) || { executed: 0, passed: 0, failed: 0, skipped: 0, timedOut: 0, totalDuration: 0 };
      agg.executed += 1;
      if (status === 'passed') agg.passed += 1;
      else if (status === 'failed') agg.failed += 1;
      else if (status === 'skipped') agg.skipped += 1;
      else if (status === 'timedOut') agg.timedOut += 1;
      agg.totalDuration += duration;
      this.suites.set(suiteName, agg);

    } catch (e) {
      console.error('Reporter onTestEnd error', e && e.stack ? e.stack : e);
    }
  }

  async onEnd() {
    try {
      const totals = [...this.suites.values()].reduce((acc, s) => {
        acc.executed += s.executed;
        acc.passed += s.passed;
        acc.failed += s.failed + s.timedOut;
        acc.skipped += s.skipped;
        acc.totalDuration += s.totalDuration || 0;
        return acc;
      }, { executed: 0, passed: 0, failed: 0, skipped: 0, totalDuration: 0 });

      const passRate = totals.executed ? (totals.passed / totals.executed) * 100 : 0;

      const suiteRows = [...this.suites.entries()].map(([suite, a]) => {
        const failed = a.failed + a.timedOut;
        const pass = a.executed ? (a.passed / a.executed) * 100 : 0;
        return { suite, executed: a.executed, passed: a.passed, failed, skipped: a.skipped, passRate: pass };
      }).sort((x, y) => x.suite.localeCompare(y.suite));

      const reasonCounts = {};
      for (const r of this.results) {
        if (r.status !== 'failed' && r.status !== 'timedOut') continue;
        const key = r.failure_bucket || 'Other';
        reasonCounts[key] = (reasonCounts[key] || 0) + 1;
      }
      const topReasons = Object.entries(reasonCounts).sort((a,b) => b[1]-a[1]).slice(0,10);

      const runTime = `${this.startTime.toISOString().slice(0,16).replace('T',' ')}`;
      const html = buildHtml({
        totals,
        passRate,
        suiteRows,
        rawRows: this.results,
        runTime,
        topReasons
      });

      fs.writeFileSync(path.join(this.outputDir, 'WireInsight_Automation_Exe_Report.html'), html, 'utf-8');
      fs.writeFileSync(path.join(this.outputDir, 'results.json'), JSON.stringify({ totals, passRate, suites: suiteRows, rows: this.results }, null, 2), 'utf-8');

      console.log(`✅ Custom HTML report written to ${path.join(this.outputDir, 'WireInsight_Automation_Exe_Report.html')}`);
    } catch (e) {
      console.error('Reporter onEnd error', e && e.stack ? e.stack : e);
    }
  }
}

/* -------------------- Helpers -------------------- */

function guessImageMime(contentType = '', filePath = '') {
  const ct = (contentType || '').toLowerCase();
  if (ct.startsWith('image/')) return ct;
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.jpg' || ext === '.jpeg') return 'image/jpeg';
  if (ext === '.webp') return 'image/webp';
  if (ext === '.png') return 'image/png';
  return 'image/png';
}

function bucketFailure(msg = '', status = '') {
  const m = (msg || '').toLowerCase();
  if (/element.*not.*found/.test(m) || /waiting.*locator/.test(m) || /locator\(.*\).*not found/.test(m) || /no node found/.test(m) || /unable to locate/.test(m)) return 'Element not found / Locator';
  if (status === 'timedOut' || /timeout|exceeded.*timeout/.test(m)) return 'Timeout';
  if (/network|fetch|request|http|status.*(4\d\d|5\d\d)/.test(m)) return 'Network/HTTP';
  if (/expect\(|assert|assertion/.test(m)) return 'Assertion failed';
  return 'Other';
}

function escapeHtml(s = '') {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function badge(status) {
  const color = status === 'passed' ? '#22c55e' : status === 'failed' ? '#ef4444' : status === 'skipped' ? '#a3a3a3' : status === 'timedOut' ? '#f97316' : '#64748b';
  return `<span style="background:${color};color:white;padding:4px 8px;border-radius:12px;font-size:12px">${escapeHtml(status)}</span>`;
}

function formatSeconds(ms) {
  if (!ms) return '0.0s';
  return `${(ms/1000).toFixed(1)}s`;
}

function toFileHref(p) {
  if (!p) return '';
  const absolute = path.resolve(p);
  const urlPath = absolute.replace(/\\/g, '/');
  return 'file:///' + urlPath.replace(/^\/+/, '');
}

/* -------------------- HTML Builder -------------------- */

function rowHtml(r) {
  const errShort = r.status === 'failed' && r.error_message ? (r.error_message.length > 110 ? r.error_message.slice(0,110) + '…' : r.error_message) : '';

  const screenshotHref = r.screenshot ? toFileHref(path.join(process.cwd(), 'test-report', r.screenshot)) : '';
  const traceHref = r.trace ? toFileHref(path.join(process.cwd(), 'test-report', r.trace)) : '';

  const screenshotButton = r.screenshotDataUrl ? `<button class="btn btn-sm btn-primary" data-action="open-screenshot" data-dataurl="${r.screenshotDataUrl}" data-href="${escapeHtml(screenshotHref)}">View Screenshot</button>`
    : (r.screenshot ? `<a class="btn btn-sm btn-primary" href="${escapeHtml(screenshotHref)}" target="_blank" rel="noopener">Open screenshot</a>` : '');

  const traceButton = r.trace ? `<a class="btn btn-sm" href="${escapeHtml(traceHref)}" target="_blank" rel="noopener">Open trace</a>` : '';

  const details = r.status === 'failed' ? `
    <details style="margin-top:6px">
      <summary style="cursor:pointer;color:#ef4444"><strong>View error details</strong></summary>
      <div style="padding:8px 0">
        ${r.failure_bucket ? `<div><em>Bucket:</em> ${escapeHtml(r.failure_bucket)}</div>` : ''}
        ${r.error_snippet ? `<pre style="white-space:pre-wrap;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:8px;margin:8px 0">${escapeHtml(r.error_snippet)}</pre>` : ''}
        ${r.error_message ? `<pre style="white-space:pre-wrap;background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:8px;margin:8px 0">${escapeHtml(r.error_message)}</pre>` : ''}
        ${r.error_stack ? `<pre style="white-space:pre-wrap;background:#f1f5f9;border:1px solid #e2e8f0;border-radius:8px;padding:8px;margin:8px 0">${escapeHtml(r.error_stack)}</pre>` : ''}
      </div>
    </details>` : '';

  return `
    <tr>
      <td>${escapeHtml(r.project)}</td>
      <td>${escapeHtml(r.suite)}</td>
      <td>${escapeHtml(r.test_case)}${details}</td>
      <td>${badge(r.status)} ${errShort ? `<div style="color:#ef4444;font-size:12px;margin-top:6px">${escapeHtml(errShort)}</div>` : ''}</td>
      <td style="text-align:center">${screenshotButton}</td>
      <td style="text-align:center">${traceButton}</td>
      <td style="text-align:right">${formatSeconds(r.duration)}</td>
    </tr>
  `;
}

function buildHtml({ totals, passRate, suiteRows, rawRows, runTime, topReasons }) {
  const summaryRowsHtml = suiteRows.map(r => `
    <tr>
      <td><strong>${escapeHtml(r.suite)}</strong></td>
      <td style="text-align:right">${r.executed}</td>
      <td style="text-align:right">${r.passed}</td>
      <td style="text-align:right">${r.failed}</td>
      <td style="text-align:right">${r.skipped}</td>
      <td style="text-align:right">${r.passRate.toFixed(1)}%</td>
    </tr>`).join('');

  const rowsHtml = rawRows.slice().sort((a,b) => {
    const af = a.status === 'failed' || a.status === 'timedOut';
    const bf = b.status === 'failed' || b.status === 'timedOut';
    if (af && !bf) return -1;
    if (!af && bf) return 1;
    if (a.suite !== b.suite) return a.suite.localeCompare(b.suite);
    return a.test_case.localeCompare(b.test_case);
  }).map(rowHtml).join('');

  const topReasonsHtml = topReasons.length ? topReasons.map(([k,v]) => `<div style="display:flex;justify-content:space-between"><span>${escapeHtml(k)}</span><strong>${v}</strong></div>`).join('') : '—';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1" />
<title>WireInsight UI Automation Test Report</title>
<style>
  body { font-family: system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif; margin:24px; color:#0f172a; }
  .card { border:1px solid #e5e7eb; border-radius:12px; padding:16px; margin-bottom:20px; }
  .grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap:12px; }
  .metric { background:#f8fafc; border:1px solid #e5e7eb; border-radius:10px; padding:12px; text-align:center; }
  .metric h2 { margin:0; font-size:28px; }
  table { width:100%; border-collapse:collapse; }
  th, td { padding:10px; border-bottom:1px solid #e5e7eb; vertical-align:top; }
  th { background:#f1f5f9; text-align:left; }
  .footer { color:#64748b; font-size:12px; margin-top:20px; }
  .btn { display:inline-block; border:1px solid transparent; border-radius:6px; padding:6px 10px; cursor:pointer; font-size:12px; text-decoration:none; color:#0f172a; background:#eef2ff; border-color:#e0e7ff; }
  .btn-sm { padding:5px 9px; font-size:12px; }
  .btn-primary { background:#2563eb; color:#fff; border-color:#1e3a8a; }
  .modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.45); display: none; align-items: center; justify-content: center; z-index: 9999; }
  .modal { background: #fff; max-width: 90vw; max-height: 90vh; border-radius: 10px; overflow: auto; box-shadow: 0 10px 30px rgba(0,0,0,.25); }
  .modal-header { display:flex; align-items:center; justify-content:space-between; padding:10px 14px; border-bottom:1px solid #e5e7eb; position: sticky; top:0; background:#fff; z-index:1; }
  .modal-body { padding: 12px; }
  .modal-body img { max-width: 100%; height: auto; border-radius: 6px; border:1px solid #e5e7eb; }
  .close-x { background:none; border:none; font-size:20px; cursor:pointer; line-height:1; padding:0 6px; }
  details > summary { cursor:pointer; }
</style>
</head>

<!-- Screenshot Modal -->
<div id="screenshot-modal-overlay" class="modal-backdrop" aria-hidden="true">
  <div class="modal" role="dialog" aria-modal="true" aria-labelledby="shotModalTitle">
    <div class="modal-header">
      <div id="shotModalTitle"><strong>Screenshot</strong></div>
      <button class="close-x" title="Close" aria-label="Close">&times;</button>
    </div>
    <div class="modal-body">
      <div id="shotModalContent"></div>
    </div>
  </div>
</div>

<body>
  <h1>WireInsight UI Automation Test Report</h1>

  <div class="card">
    <div class="grid">
      <div class="metric"><div>Total Test Executed</div><h2>${totals.executed}</h2></div>
      <div class="metric"><div>Test Passed</div><h2 style="color:#22c55e">${totals.passed}</h2></div>
      <div class="metric"><div>Test Failed</div><h2 style="color:#ef4444">${totals.failed}</h2></div>
      <div class="metric"><div>Test Skipped</div><h2 style="color:#a3a3a3">${totals.skipped}</h2></div>
      <div class="metric"><div>Pass Rate</div><h2>${passRate.toFixed(1)}%</h2></div>
      <div class="metric"><div>Top Failure Reasons</div><div style="text-align:left;margin-top:8px">${topReasonsHtml}</div></div>
    </div>
  </div>

  <div class="card">
    <h2>Suite Summary</h2>
    <table>
      <thead>
        <tr>
          <th>Suite</th>
          <th style="text-align:right">Executed</th>
          <th style="text-align:right">Passed</th>
          <th style="text-align:right">Failed</th>
          <th style="text-align:right">Skipped</th>
          <th style="text-align:right">Pass Rate</th>
        </tr>
      </thead>
      <tbody>${summaryRowsHtml}</tbody>
    </table>
  </div>

  <div class="card">
    <h2>Detailed Results</h2>
    <table>
      <thead>
        <tr>
          <th>Project</th><th>Suite</th><th>Test Case</th><th>Status</th><th>Screenshot</th><th>Trace</th><th style="text-align:right">Duration</th>
        </tr>
      </thead>
      <tbody>${rowsHtml}</tbody>
    </table>
  </div>

  <div class="footer">Generated ${escapeHtml(runTime)}</div>
</body>

<script>
(function(){
  const overlay = document.getElementById('screenshot-modal-overlay');
  const content = document.getElementById('shotModalContent');
  const closeBtn = overlay.querySelector('.close-x');

  function openModalWithImage(src, fallbackHref) {
    if (src && src.startsWith('data:image/')) {
      content.innerHTML = '<img alt="screenshot" src="' + src + '"/>';
    } else if (fallbackHref) {
      content.innerHTML = '<div style="padding:10px">No embedded image available. <a href="' + fallbackHref + '" target="_blank" rel="noopener">Open screenshot file</a></div>';
    } else {
      content.innerHTML = '<div style="padding:10px;color:#ef4444">Screenshot not available</div>';
    }
    overlay.style.display = 'flex';
    overlay.setAttribute('aria-hidden', 'false');
  }

  function closeModal() {
    overlay.style.display = 'none';
    overlay.setAttribute('aria-hidden', 'true');
    content.innerHTML = '';
  }

  overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
  closeBtn.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  // Delegate "View Screenshot" clicks
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action="open-screenshot"]');
    if (!btn) return;
    const dataUrl = btn.getAttribute('data-dataurl') || '';
    const href = btn.getAttribute('data-href') || '';
    openModalWithImage(dataUrl, href);
  });
})();
</script>
</html>`;
}

module.exports = CustomHtmlReporter;