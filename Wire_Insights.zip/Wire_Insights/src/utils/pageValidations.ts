/**
 * This function is used for handle the page validation; like user can look for the any text on the page and validate it dynamically.
 * @author Suhas Ghodake
 */
import { Page, Frame, Locator, expect } from '@playwright/test';
import { Utility } from "utils/utility";


export type CheckOptions = {
  timeout?: number;
  readiness?: Locator;
  ignoreCase?: boolean;
  tryFallbackText?: boolean;
  // optional feature toggles
  highlight?: boolean;
  highlightDuration?: number;
};

function escapeRegex(text: string) {
  return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}



export class pageValidations {
    private page: Page;
    private util: Utility;

    constructor(page: Page) {
        this.page = page;
        this.util = new Utility(this.page);

    }



/**
 * Finds the first VISIBLE element that contains `text` and returns its Locator.
 * Throws a descriptive error if nothing becomes visible within the provided timeboxes.
 */
async checkThatPageContains(
        page: Page,
        text: string,
        options: CheckOptions = {}
    ): Promise<Locator> {
    const {
        timeout = 8000,
        readiness,
        ignoreCase = true,
        tryFallbackText = true,
    } = options;

    // 0) If you have a stable element that signals the page/view is ready, wait for it first.
    if (readiness) {
        await expect(readiness).toBeVisible({ timeout });
    }

    // 1) Build candidate locators (role-first for buttons, then common tags w/ hasText)
    const tags = ['span', 'a', 'div', 'label', 'p', 'i', 'button'] as const;

    // Case-insensitive exact match for button label if requested
    const buttonName =
        ignoreCase ? new RegExp(`${(text)}`, 'i') : text;

    const candidates: Locator[] = [];

    // Prefer role-based button for better a11y targeting
    candidates.push(page.getByRole('button', { name: buttonName }));

    // Tag-based scans (hasText matches descendants too; good for nested spans etc.)
    for (const tag of tags) {
        // Skip "button" here because we already added the role-based match above
        if (tag === 'button') continue;
        candidates.push(page.locator(tag, { hasText: text }));
    }

    // 2) Try each candidate with visibility-based waits
    for (const candidate of candidates) {
        try {
            const first = candidate.first();
            // Robust visibility wait (auto-retries until visible or timeout)
            await expect(first).toBeVisible({ timeout });
            // await highlightIfSupported(first, this); // non-blocking helper (optional)
            return first;
        } catch {
            // Not visible yet or wrong selector — try next candidate
        }
    }

    // 3) Fallback: generic text finder (often catches cases missed by tag/role)
    if (tryFallbackText) {
        const generic = page.getByText(text, { exact: false });
        try {
            await expect(generic.first()).toBeVisible({ timeout: Math.max(4000, timeout / 2) });
            await this.util.highlightElement(generic,10000);
            // await highlightIfSupported(generic.first(), this);
            return generic.first();
        } catch {
            // continue to final throw
        }
    }

    // 4) Nothing visible after all strategies
    throw new Error(`Element containing text "${text}" did not become VISIBLE after all checks (timeout ≈ ${timeout} ms per attempt).`);
}



}

