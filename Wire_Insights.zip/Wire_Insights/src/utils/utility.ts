import { Page, Frame, Locator, expect } from '@playwright/test';
/**
 * Functions from this class will help you in test cases for customize the code/ generic code
 * @author Suhas Ghodake
 */
export class Utility {

    private page: Page;


    constructor(page: Page) {
        this.page = page;
    }
    /**
     * This function is very helpful in highlight the element.
     * @param locator 
     */

    async highlightElement(locator: Locator, duration = 10_000): Promise<void> {
        // Apply highlight styles
        await locator.evaluate((el: HTMLElement) => {
            el.style.outline = '3px solid red';
            el.style.backgroundColor = 'yellow';
            el.style.transition = 'outline 0.2s ease, background-color 0.2s ease';
        });

        // Wait for the given duration
        await new Promise((resolve) => setTimeout(resolve, duration));
    }

    /**
     * This function is handling the cookies banner on the screen.
     * @param page 
     */
    async handleCookieBanner(page: Page) {
        // Wait briefly to see if a banner shows up (don’t block forever)
        const banner = this.page.locator('[id*="understoodCookies_button"]');

        // Don’t fail if it never appears—many environments disable it
        if (await banner.first().isVisible().catch(() => false)) {
            // Prefer role-based clicks with text; adapt to your site’s labels
            const accept = this.page.getByRole('button', { name: /accept.*cookies|agree|ok/i });
            const reject = this.page.getByRole('button', { name: /reject|decline|only.*necessary/i });

            if (await accept.isVisible().catch(() => false)) {
                await accept.click({ timeout: 5_000 });
            } else if (await reject.isVisible().catch(() => false)) {
                await reject.click({ timeout: 5_000 });
            } else {
                // Fallback: click inside known banner selector
                await banner.locator('button', { hasText: /accept|agree|ok/i }).first().click({ timeout: 5_000 }).catch(() => { });
            }

        }
        else {
            await banner.click();
        }
    }

    /**
     * This function is returning new opened page/tab after clicking on elements
     * @returns new page/tab
     */
    async switchToTab() {
        const [popup] = await Promise.all([
            this.page.waitForEvent('popup')   // waits for the *new tab*
        ]);

        // Step 3: wait until the popup is ready
        await popup.waitForLoadState('domcontentloaded');

        console.log('New tab URL:', popup.url());

        // Step 4: return the popup for further actions
        return popup;
    }

    /**
     * This function help us to navigate on the page inside Visualizer
     * @param pageName 
     */
    async navigateTothe(page: Page, pageName: string) {
        const pageNameLocate = page.locator(`//div[contains(@aria-label, "${pageName}")]`);
        await pageNameLocate.click();
        // await this.page.getByRole('button', { name: `Expand "${pageName}"` }).click();
    }


    /**
     * This function help us to select the specific time range on visualizer. In the following formate you need to send the parameters
     * today- Today
     * yesterday- Yesterday
     * last 7 days- Last 7 Days
     * date range-Nov 1, 2025 - Dec 9, 2025      // add a space after the year // need to select todays date-1
     * @param page 
     * @param timeLine 
     */
    async selectTimeLine(page: Page, timeLine: string) {
        const selectTimeline = page.locator(`button:has-text("${timeLine}")`);
        const calendarElement = page.locator("//div[@role='menu']");
        const months = page.locator("//div[@role='menu']//div[contains(@class,'date__months ')]/div/button/span/span");  // Here you have the list of the months
        const dates = page.locator("(//div[@role='menu']//div[contains(@class,'calendar-days')])[2]/div/button"); // Here you have all the visible date on the first date picker 
        const secondDate = page.locator("(//div[@role='menu']//div[contains(@class,'calendar-days')])[4]/div/button")   // Here you have all the visible dates on the second date picker 
        const currentMonth = new Date().toLocaleString('default', { month: 'long' });
        const okBtn = page.locator("//button[normalize-space()='Ok']");


        if (timeLine !== 'Today' && timeLine !== 'Yesterday' && timeLine !== 'Last 7 Days') {
            const dateRange = page.locator(`button:has-text("Custom...")`);
            await dateRange.click();
            if (await calendarElement.isVisible({ timeout: 3000 })) {
                // This code is for the first block of datepicker 
                const match = timeLine.match(/^[A-Za-z]+/); // match letters at start
                const firstMonth = match?.[0] ?? ''; // fallback to empty string if no match
                console.log(firstMonth); // output month

                await page.locator(`//button[contains(normalize-space(), '${currentMonth}')]`).first().click();
                // Here I am selecting the month
                const monthCount = await months.count();
                for (let i = 0; i < monthCount; i++) {
                    const m = months.nth(i);
                    const text = (await m.textContent())?.trim() ?? '';
                    if (text.toLowerCase().includes(firstMonth.toLowerCase())) {
                        await m.click();
                        break; // stop after the first match
                    }

                }
                // Here I am selecting date 
                const dateMatch = timeLine.match(/^[A-Za-z]{3,}\s+(\d{1,2})/);
                const day = dateMatch ? dateMatch[1] : "";
                console.log(day); // Output: date 

                const dateCount = await dates.count();
                for (let i = 0; i < dateCount; i++) {
                    const d = dates.nth(i);
                    const text = (await d.textContent())?.trim() ?? '';
                    if (text.toLowerCase().includes(day.toLowerCase())) {
                        await d.click();
                        break; // stop after the first match
                    }

                }

                // This code is for the second block of datepicker 
                const match2 = timeLine.match(/-\s+([A-Za-z]+)/); // match letters at start
                const secondMonth = match2?.[1] ?? ''; // fallback to empty string if no match
                console.log(secondMonth); // output month

                await page.locator(`//button[contains(normalize-space(), '${currentMonth}')]`).first().click();
                // Here I am selecting the month
                const secondMonthCount = await months.count();
                for (let i = 0; i < secondMonthCount; i++) {
                    const m = months.nth(i);
                    const text = (await m.textContent())?.trim() ?? '';
                    if (text.toLowerCase().includes(secondMonth.toLowerCase())) {
                        await m.click();
                        break; // stop after the first match
                    }

                }
                // Here I am selecting date 
                const secondDateMatch = timeLine.match(/-\s+[A-Za-z]+\s+(\d{1,2})/);
                const secondDay = secondDateMatch ? secondDateMatch[1] : "";
                console.log(secondDay); // Output: date 

                const secondDateCount = await secondDate.count();
                for (let i = 0; i < secondDateCount; i++) {
                    const d = secondDate.nth(i);
                    const text = (await d.textContent())?.trim() ?? '';
                    if (text.toLowerCase().includes(secondDay.toLowerCase())) {
                        await d.click();
                        break; // stop after the first match
                    }

                }


            }
            await okBtn.click();   // Finally clicking on the ok button after selection of date


        }
        else {
            await selectTimeline.click();
        }

    }
   /**
    * This function will return you todays date with YYYY/MM/DD this format 
    */
    async todayDate(): Promise<string> {
        const today = new Date();
        const formattedDate = today.toISOString().slice(0, 10).replace(/-/g, '/');
        console.log("Today's date is the--->", formattedDate);
        return formattedDate;
    }

}
