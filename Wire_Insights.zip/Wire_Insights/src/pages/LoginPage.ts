import { Page, Locator, expect } from 'playwright/test';
import { Utility } from 'utils/utility';

export class LoginPage {

    private page: Page;
    util:Utility;


    //Declare private locator globally 
    private DMloginBtn: Locator;
    private loginScreenText: Locator;
    private MSloginBtn: Locator;
    private MSEmail: Locator;
    private MSPassword: Locator;
    private signInBtn: Locator;
    private DMPortalLink: Locator;
    private visualizerLink: Locator;


    constructor(page: Page) {
        this.page = page;
        this.util = new Utility(this.page);
        // Initialize the locator into this constructor using this keyword 
        this.DMloginBtn = page.locator("a[id='loginTopRight_button']");
        this.loginScreenText = page.locator("h2[class='formH2']");
        this.MSloginBtn = page.locator("a[id=login_button]");
        this.MSEmail = page.locator("input[type=email]");
        this.MSPassword = page.locator("input[type=password]");
        this.signInBtn = page.locator("input[type=submit]"); // we can use it in Stay signed in page.
        this.DMPortalLink = page.locator("a[id='toPortal_link']");
        this.visualizerLink = page.locator('h5', { hasText: 'WIRE Insight' }).locator('xpath=following-sibling::a[normalize-space()="Visualizer"]');
        
    }



    // write down all the action functions/methods here 

    /* 
    This function will navigate you on the Digital marketplace landing page.
    */
    async navigateToLoginPage() {
        await this.page.goto('/');
        // await this.page.pause();
    }

    /* 
    This function is clicking on Log in button on Digital marketplace 
     */
    async clickOnLoginBtn() {
        // await this.util.highlightElement(this.DMloginBtn,3000);
        await this.DMloginBtn.click();
        const message = await this.loginScreenText.allTextContents();
        console.log("This the message I can see after click on log in button:", message);
        expect(message);

    }
    /**
     * This function is working for login via ms account
     * @param email 
     * @param password
     * 
     */

    async loginWithMSAccount(email: string, password: string) {
        await this.MSloginBtn.click();
        await this.MSEmail.fill(email);
        await this.signInBtn.click();
        await this.MSPassword.clear();
        await this.MSPassword.fill(password);
        await this.signInBtn.click();
        await this.signInBtn.click();
        await expect(this.DMPortalLink).toBeVisible();
    }
    /**
     * 
     */

    async navigateToVisualizer(): Promise<Page> {
        // Step 1: click DM Portal link (same tab)
        // await this.DMPortalLink.click();

        // Step 2: click Visualizer and capture the popup tab
        const [popup] = await Promise.all([
            this.page.waitForEvent('popup'),   // waits for the *new tab*
            this.visualizerLink.click(),       // triggers the popup
        ]);

        // Step 3: wait until the popup is ready
        await popup.waitForLoadState('domcontentloaded');

        // Step 4: assert title with auto-retry
        await expect(popup).toHaveTitle('WIRE Insights');

        console.log('New tab URL:', popup.url());

        // Step 5: return the popup for further actions
        return popup;
    }



}