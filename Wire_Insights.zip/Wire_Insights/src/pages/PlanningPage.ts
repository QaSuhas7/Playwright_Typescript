import { expect, Page, Locator } from '@playwright/test'
import { error } from 'console';
import { pageValidations } from 'utils/pageValidations';
import { Utility } from 'utils/utility';

/**
 * @author Suhas Ghodake 
 * In this class you can find the all function and locators related of Planning page   
 */


type ShiftTime = { from: string; to: string };
type ShiftPlan = ShiftTime[];

export class PlanningPage {

    //Setting up the "Form" & "To" for all the days 
    private readonly plan: ShiftPlan = [
        { from: '06:00', to: '14:00' },
        { from: '14:00', to: '22:00' },
        { from: '22:00', to: '06:00' },
    ];
    // This is indexing which started from the 
    private readonly baseFrom = 1;
    private readonly baseTo = 0;


    util: Utility;
    pageValidation: pageValidations;
    private shiftEditor: string;
    private shiftHistory: string;
    private kpiEditor: string;
    private editDownTime: string;
    private editPRI: string;
    private currentDownTime: string;
    private editedDownTime: string;
    private currentPRI: string;
    private editedPRI: string;
    private enterPRI: string;

    constructor(page: Page) {

        this.util = new Utility(page);
        this.pageValidation = new pageValidations(page);
        this.shiftEditor = "//div[text()='Shift Editor']/ancestor::a";
        this.shiftHistory = "//div[text()='Shifts History']/ancestor::a";
        this.kpiEditor = "//div[text()='KPI Editor']/ancestor::a";
        this.editDownTime = "//table[@class='q-table']//tbody[2]/tr[1]/td[2]"; // Editing downtime for any first machine
        this.editPRI = "//table[@class='q-table']//tbody[2]/tr[1]/td[3]"; // Editing Planned runtime per item 
        this.currentDownTime = "(//table[@class='q-table'])[2]/tbody/tr/td[2]"; // This is the current downtime before edit.
        this.editedDownTime = "(//table[@class='q-table'])[2]/tbody/tr/td[3]"; // this is the edited downtime after edit.
        this.currentPRI = "(//table[@class='q-table'])[2]/tbody/tr/td[4]"; //this is the current pri before edit.
        this.editedPRI = "(//table[@class='q-table'])[2]/tbody/tr/td[5]"; //this is the edited pri after edit.
        this.enterPRI = "//input[@type='number']";

    }
    /**
     * 
     * @param page 
     */
    async validatePlanningPage(page: Page) {
        //Navigating to the planning page
        await this.util.navigateTothe(page, 'Planning');   // This function is clicking on the given page name e.g Equipment, ReportingD
        await page.locator(this.shiftEditor).click();
        await this.pageValidation.checkThatPageContains(page, "Validation Date");

    }

    /**
     * Here user is filling shift data for days 
     */
    async selectDateForShift(page: Page) {
        // Filling todays date in sift starts from date
        const today = new Date();
        const formattedDate = today.toISOString().slice(0, 10).replace(/-/g, '/');
        console.log("Today's date is the--->", formattedDate);
        await page.getByRole('textbox', { name: 'Starts From' }).fill(formattedDate);


    }
    /**
     * Here user is filling shift data for monday 
     * @param page 
     * @param day 
     */

    async fillDaysShiftData(page: Page, day: string) {
        // 1) Enable day
        const dayCheckbox = page.getByRole('checkbox', { name: day, exact: true });
        await expect(dayCheckbox, `Day checkbox not visible: ${day}`).toBeVisible();
        await dayCheckbox.check();

        // 2) Enable 3 shifts for this day (the Shift checkboxes are also globally sequential)
        // If they are per-day scoped (reset to 0..2 inside each day container), use Pattern B below.
        await this.enableShiftsForDay(page, day);

        // 3) Compute index offset for this day and fill From/To
        await this.fillShiftTimesForDay(page, day);
    }



    async enableShiftsForDay(page: Page, day: string) {
        // Derive the day index from the order of day checkboxes on the page
        const allDayCheckboxes = page.getByRole('checkbox', { name: /monday|tuesday|wednesday|thursday|friday|saturday|sunday/i });
        const dayCount = await allDayCheckboxes.count();

        // Find day index by matching accessible name
        let dayIndex = -1;
        for (let i = 0; i < dayCount; i++) {
            const label = await allDayCheckboxes.nth(i).getAttribute('aria-label').catch(() => null);
            const textMatch =
                (await allDayCheckboxes.nth(i).innerText().catch(() => '')) ||
                (await allDayCheckboxes.nth(i).textContent().catch(() => ''));
            const visibleName = (label || textMatch || '').trim();
            if (visibleName.toLowerCase().includes(day.toLowerCase())) {
                dayIndex = i; break;
            }
        }

        // If you know the exact order of days, you can also map:
        // const dayIndex = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].indexOf(day);

        if (dayIndex < 0) {
            console.warn(`[WARN] Could not determine dayIndex for '${day}'. Assuming 0.`);
            dayIndex = 0;
        }

        // Shift checkboxes globally sequential index:
        const shiftCheckboxes = page.getByRole('checkbox', { name: 'Shift' });
        for (let s = 0; s < this.plan.length; s++) {
            const globalShiftIdx = dayIndex * this.plan.length + s; // 0..2 for Monday, 3..5 for Tuesday, etc.
            const box = shiftCheckboxes.nth(globalShiftIdx);
            await expect(box, `Shift checkbox missing for ${day} #${s + 1} (nth=${globalShiftIdx})`).toBeVisible();
            await box.check();
        }
    }

    private async fillShiftTimesForDay(page: Page, day: string) {
        // Determine dayIndex same as above
        const orderedDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        const dayIndex = orderedDays.indexOf(day);
        if (dayIndex < 0) throw new Error(`Day '${day}' not found in orderedDays`);

        const fromList = page.getByRole('textbox', { name: 'From' });
        const toList = page.getByRole('textbox', { name: 'To' });

        // Defensive: ensure lists have enough inputs
        const totalFrom = await fromList.count();
        const totalTo = await toList.count();
        const required = (dayIndex + 1) * this.plan.length; // up to current day
        if (totalFrom < required || totalTo < required) {
            throw new Error(
                `Not enough time boxes by ${day}. From=${totalFrom}, To=${totalTo}, required at least=${required}`
            );
        }

        // Offset per day = dayIndex * number of shifts
        const dayOffset = dayIndex * this.plan.length;

        for (let s = 0; s < this.plan.length; s++) {
            const fromIdx = this.baseFrom + dayOffset + s;
            const toIdx = this.baseTo + dayOffset + s;

            const fromBox = fromList.nth(fromIdx);
            const toBox = toList.nth(toIdx);

            await expect(fromBox, `From not visible: ${day} Shift ${s + 1} (nth=${fromIdx})`).toBeVisible();
            await expect(toBox, `To not visible: ${day} Shift ${s + 1} (nth=${toIdx})`).toBeVisible();

            await this.clearAndType(fromBox, this.plan[s].from);
            await this.clearAndType(toBox, this.plan[s].to);

            console.log(`[DEBUG] ${day} Shift ${s + 1}: From nth=${fromIdx} -> ${this.plan[s].from}, To nth=${toIdx} -> ${this.plan[s].to}`);
        }
    }

    private async clearAndType(locator: ReturnType<Page['locator']>, value: string) {
        await locator.fill('');
        await locator.press('Control+A');
        await locator.press('Delete');
        await locator.type(value, { delay: 20 });
    }

    /**
     * This function will help you to fill shift data for entire week
     */
    async fillShiftDataForWeek(page: Page) {
        await this.fillDaysShiftData(page, "Monday");
        await this.fillDaysShiftData(page, "Tuesday");
        await this.fillDaysShiftData(page, "Wednesday");
        await this.fillDaysShiftData(page, "Thursday");
        await this.fillDaysShiftData(page, "Friday");
        await this.fillDaysShiftData(page, "Saturday");
        await this.fillDaysShiftData(page, "Sunday");
    }
    /**
     * Here we are clicking on the save button
     */
    async clickOnSaveBtn(page: Page) {
        await page.getByRole('button', { name: 'Save' }).click();
    }

    async expect(box: Locator, arg1: string) {
        throw new Error('Function not implemented.');
    }
    /**
     * 
     * @param page 
     */
    async clickOnShiftHistory(page: Page) {
        await this.util.navigateTothe(page, 'Planning');   // This function is clicking on the given page name e.g Equipment, ReportingD
        await page.locator(this.shiftHistory).click();

    }
    /**
     * Clicking on the KPI editor
     * @param page 
     */
    async clickOnKPIEditor(page: Page) {
        await this.util.navigateTothe(page, 'Planning');
        await page.locator(this.kpiEditor).click();
    }

    /**
     * Here I am resetting KPI for very first row/machine
     */
    async resetKIP(page: Page) {
        if (await page.getByRole('button', { name: 'Reset Downtime', exact: true }).first().isEnabled()) {
            await page.getByRole('button', { name: 'Reset Downtime', exact: true }).first().click();
            await page.getByRole('button', { name: 'Ok', exact: true }).first().click();
            await page.getByRole('button', { name: 'Reset PRI', exact: true }).first().click();
            await page.getByRole('button', { name: 'Ok', exact: true }).first().click();
        }

    }

    /**
     * Click on the Edit button
     * @param page 
     */
    async editKPI(page: Page) {
        await this.resetKIP(page);
        await page.getByRole('button', { name: 'Edit', exact: true }).click();
        await page.locator(this.editDownTime).click();
        await page.getByLabel('', { exact: true }).fill('10');
        await page.getByRole('button', { name: 'Set', exact: true }).click();
        await page.locator(this.editPRI).click();
        await page.locator(this.enterPRI).nth(1).fill('1200');
        // await page.getByLabel('', { exact: true }).fill('1200');
        await page.getByRole('button', { name: 'Set', exact: true }).click();
        await page.getByRole('button', { name: 'Save' }).click();
    }

    /**
     * 
     */
    async validateKPIEditor(page: Page) {
        await this.pageValidation.checkThatPageContains(page, "The changes will affect future and historical OEE and KPI calculations.");
        const currentDT = (await page.locator(this.currentDownTime).innerText()).trim();
        const editedDT = (await page.locator(this.editDownTime).innerText()).trim();
        const currentpri = (await page.locator(this.currentPRI).innerText()).trim();
        const editedpri = (await page.locator(this.editedPRI).innerText()).trim();
        console.log(`Edited downtime:`, editedDT)
        console.log(`Edited editedpri:`, editedpri)
        if (editedDT === '10 min' && editedpri === '1200') {
            console.log(`===> Your KPI downtime and editor got changed`);
        }
        else {
            throw new Error("Hey KPI editor is not changed or edited.")
        }
        await page.getByRole('button', { name: 'Ok' }).click();

    }


}




