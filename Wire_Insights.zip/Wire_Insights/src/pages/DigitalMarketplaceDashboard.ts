import { Page, Locator, expect } from 'playwright/test';


export class digitalMarketplaceDash {

    private page: Page;
    private clickOrg: Locator;
    private DMPortalLink: Locator;
    private acceptCookies: Locator;

    constructor(page: Page) {
        this.page = page;
        this.clickOrg = page.locator(`#dropdownOrgButton`);
        this.DMPortalLink = page.locator("#toPortal_link");
        this.acceptCookies = page.locator('#understoodCookies_button');



    }
    /**
     * Using this function user can switch the organization
     * @param org this the name of organization
     *  at line no. 31 in if logic we are handling cookies
     */
    async switchOrg(org: string) {
        const currentUrl = this.page.url();
        console.log("The current Url;", currentUrl);
        await this.clickOrg.click();
        let orgName = this.page.getByRole('button', { name: org });
        await orgName.click();
    }

}


