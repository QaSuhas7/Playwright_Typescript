import { Page, Locator, expect } from 'playwright/test';
import { LoginPage } from '@pages/LoginPage';
import { Utility } from 'utils/utility';

/**
 * @author Suhas Ghodake
 */
export class equipmentPage {
    // We can create a generic function for switching the pages 
    private page: Page;
    loginPage: LoginPage;
    util: Utility;


    constructor(page: Page) {
        this.page = page;
        this.loginPage = new LoginPage(this.page);
        this.util = new Utility(this.page);


    }
    /**
     * 
     * @param page 
     */
    async clickOnEquipmentPage(page: Page) {
        await this.util.navigateTothe(page, 'Equipment');   // This function is clicking on the given page name e.g Equipment, Reporting
    }

}


