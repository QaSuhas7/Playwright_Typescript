import { test as base, expect, Page } from '@playwright/test';
import { test as authTest } from '@fixtures/auth.fixture';

import { LoginPage } from '@pages/LoginPage';
import { digitalMarketplaceDash } from '@pages/DigitalMarketplaceDashboard';
import { equipmentPage } from '@pages/EquipmentPage';
import { pageValidations } from 'utils/pageValidations';
import { Utility } from 'utils/utility';
import { PlanningPage } from '@pages/PlanningPage';



type AppPages = {
    login: LoginPage;            // bound to root
    digitalMarketPlace: digitalMarketplaceDash;
    equipment: equipmentPage;
    pageValidation: pageValidations;
    util: Utility;
    planning: PlanningPage;


};

export const test = authTest.extend<{ pages: AppPages }>({
    pages: async ({ authPage }, use) => {
        // Root/login POM
        const login = new LoginPage(authPage);
        // Instantiate all POMs with their correct page contexts
        const equipment = new equipmentPage(authPage);
        const digitalMarketPlace = new digitalMarketplaceDash(authPage);
        const pageValidation = new pageValidations(authPage);
        const util = new Utility(authPage);
        const planning = new PlanningPage(authPage);

        const pages: AppPages = {
            login,
            digitalMarketPlace,
            equipment,
            pageValidation,
            util,
            planning,
            
        };

        await use(pages);

    },
});

export { expect };
