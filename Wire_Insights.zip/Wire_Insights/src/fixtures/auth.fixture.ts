
import { test as base, expect, Page, Frame } from '@playwright/test';
import { LoginPage } from '@pages/LoginPage';
// import {LoginPage} from '@pages/loginPage';

type AuthFixtures = {
  authPage: Page;
  frame: Frame;
};
/* Instead of writing login steps in every test, you centralize them in a fixture.
Any test that imports test from this file automatically gets:

A logged-in page (or at least a page on the login screen).
Cleaner test code. */

export const test = base.extend<AuthFixtures>({
  authPage: async ({ page }, use) => {
    // test.setTimeout(80 * 1000);
    const login = new LoginPage(page);
    await login.navigateToLoginPage();
    await login.clickOnLoginBtn();
    await login.loginWithMSAccount(process.env.EMAIL!, process.env.PASSWORD!);
    await page.waitForSelector('#toPortal_link', { state: 'visible', timeout: 10000 });
    await page.locator('#toPortal_link').click();
    await use(page); // Pass authenticated page to tests
  },
});

export { expect };
