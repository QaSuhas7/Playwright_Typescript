import { defineConfig, devices } from '@playwright/test';
import { register } from 'tsconfig-paths';
register();

import dotenv from 'dotenv';
import path from 'path';

const envName = process.env.ENV || 'test';

const envPath = path.resolve(process.cwd(), 'src', 'env', `${envName}.env`);
dotenv.config({ path: envPath });

// console.log('BASE_URL:', process.env.BASE_URL);


/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  timeout: 125000,
  testDir: path.resolve(process.cwd(), 'tests'),
  /* Run tests in files in parallel */
  fullyParallel: true,
  /* Fail the build on CI if you accidentally left test.only in the source code. */
  forbidOnly: !!process.env.CI,
  /* Retry on CI only */
  retries: process.env.CI ? 2 : 0,
  /* Opt out of parallel tests on CI. */
  workers: process.env.CI ? 1 : undefined,
  /* Reporter to use. See https://playwright.dev/docs/test-reporters */
  reporter: [
    ['html'],
    [path.join(__dirname, '..', 'src', 'utils', 'testHtmlReport.js'), { outputFolder: 'test_reports' }] //This is the custom report we have added to see the detail dashboard of executed test cases. 
  ]
  ,
  /* Shared settings for all the projects below. See https://playwright.dev/docs/api/class-testoptions. */
  use: {

    baseURL: process.env.BASE_URL,
    /* Collect trace when retrying the failed test. See https://playwright.dev/docs/trace-viewer */

    actionTimeout: 8_000,           // max for actions like click/fill
    navigationTimeout: 10_000,       // max for navigation waits

    screenshot: 'only-on-failure',   // saves a screenshot attachment
    trace: 'retain-on-failure'       // saves a .zip trace attachment

  },

  /* Configure projects for major browsers */
  projects: [
    {
      name: 'Wire_Insights',

      use: {
        browserName: 'chromium',
        headless: true,
        viewport: { width: 1920, height: 1080 }, // Desktop landscape
        deviceScaleFactor: 1,
        isMobile: false,
        hasTouch: false,
        launchOptions: {
          slowMo: 50,
          args: ['--start-maximized'],
        },
      },


    },

    // {
    //   name: 'firefox',
    //   use: { ...devices['Desktop Firefox'] },
    // },

    // {
    //   name: 'webkit',
    //   use: { ...devices['Desktop Safari'] },
    // },

    /* Test against mobile viewport. */
    // {
    //   name: 'Mobile Chrome',
    //   use: { ...devices['Pixel 5'] },
    // },
    // {
    //   name: 'Mobile Safari',
    //   use: { ...devices['iPhone 12'] },
    // },

    /* Test against branded browsers. */
    // {
    //   name: 'Microsoft Edge',
    //   use: { ...devices['Desktop Edge'], channel: 'msedge' },
    // },
    // {
    //   name: 'Google Chrome',
    //   use: { ...devices['Desktop Chrome'], channel: 'chrome' },
    // },
  ],

  /* Run your local dev server before starting the tests */
  // webServer: {
  //   command: 'npm run start',
  //   url: 'http://localhost:3000',
  //   reuseExistingServer: !process.env.CI,
  // },
});
