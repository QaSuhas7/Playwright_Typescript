import { test, expect } from '@fixtures/page.fixture'


test('Validate user is able to login into Wire Insights (visualizer)', async ({ pages, page }) => {
  const newPage = await pages.login.navigateToVisualizer();
  await pages.equipment.clickOnEquipmentPage(newPage);
  await pages.pageValidation.checkThatPageContains(newPage, "Machine Viewer");
  await pages.util.selectTimeLine(newPage,'Jan 11, 2025 - Jan 20, 2025' );
 
});
