import { test, expect } from '@fixtures/page.fixture'




test('Validate user is able to switch the organization into Wire Insights (visualizer)', async ({ pages, page }) => {
    await pages.util.handleCookieBanner(page)
    await pages.digitalMarketPlace.switchOrg("TestCenter");
});   