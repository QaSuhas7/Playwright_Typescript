import { test, expect } from '@fixtures/page.fixture'

/**
 * This test suite is talking about Planning/Shift editor
 */
test.use({ screenshot: 'only-on-failure', trace: 'on-first-retry' });
// test.setTimeout(90000);
test('Validate user is able to fill the shift data for week', async ({ pages, page }) => {
    // Navigating to the Visualizer 
    const newPage = await pages.login.navigateToVisualizer();
    await pages.planning.validatePlanningPage(newPage);
    //Selecting todays date for filling shift data
    await pages.planning.selectDateForShift(newPage);
    // Started filling shift data for the week 
    await pages.planning.fillShiftDataForWeek(newPage);
    //Clicking on the saving button
    await pages.planning.clickOnSaveBtn(newPage);
    //Validate you have saved Shifts.
    await pages.pageValidation.checkThatPageContains(newPage, "Shifts saved", { timeout: 5000 });
    // await page.pause();
});

test('Validate user is able to check shift history', async ({ pages, page }) => {
    // Navigating to the Visualizer 
    const newPage = await pages.login.navigateToVisualizer();
    // Navigate to the shift history 
    await pages.planning.clickOnShiftHistory(newPage);
    await pages.pageValidation.checkThatPageContains(newPage, await pages.util.todayDate()); // Here we are doing partial validation, we are checking last created shift plan
});

test('Validate user is able edit KPI', async ({ pages, page }) => {
    // Navigating to the Visualizer 
    const newPage = await pages.login.navigateToVisualizer();
    // Navigate to the shift history 
    await pages.planning.clickOnKPIEditor(newPage);
    // await page.pause();
    await pages.planning.editKPI(newPage);
    await pages.planning.validateKPIEditor(newPage);



});