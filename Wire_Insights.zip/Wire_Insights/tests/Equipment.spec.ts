import { test, expect } from '@fixtures/page.fixture'


test('Validate user is able to navigate equipment', async ({ pages, page }) => {
    const newPage = await pages.login.navigateToVisualizer();
    await pages.equipment.clickOnEquipmentPage(newPage);
    await pages.pageValidation.checkThatPageContains(newPage, 'Naming Editor');

});
