// import { test as base, expect, Page } from '@playwright/test';
// import { LoginPage } from '../src/pages/loginPage';



// type MyFixtures = {
//     page: Page;
// };

// export const test = base.extend<MyFixtures>({
//     page: async ({ browser }, use) => {

//         test.setTimeout(60 * 1000);
//         const context = await browser.newContext();
//         const page = await context.newPage();

//         const loginPage = new LoginPage(page);



//         await page.waitForTimeout(5000);

//         await use(page);
//         // await context.close();
//     },
// });

// export { expect } from '@playwright/test';